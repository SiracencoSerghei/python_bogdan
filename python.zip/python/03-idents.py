def print_num(num):
    print(num)


print_num(5)

if 10 > 5:
    print(True)
