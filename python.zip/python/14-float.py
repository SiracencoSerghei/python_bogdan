average_rating = 4.65

print(average_rating.is_integer())  # False
print(round(average_rating))  # 5
print(int(average_rating))  # 4
print(float(100))  # 100.0
