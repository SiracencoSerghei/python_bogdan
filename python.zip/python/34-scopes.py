c = True


def mult(a, b):
    c = a * b
    print(dir())
    return c


print(mult(100, 30))
print(dir())
