print(       'Bogdan'    ,    10



             )

def my_fn():
    print(True)
my_fn()

