my_num = 777
print(type(my_num) == int)  # True

print(type(int))
print(type(str))
print(type(bool))
print(type(list))
print(type(dict))
