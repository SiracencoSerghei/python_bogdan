product_prices = {
    'PC': 1000,
    'Mobile Phone': 200,
    'Tablet': 350,
    'Camera': 700
}

for k, v in product_prices.items():
    print(k, v)
