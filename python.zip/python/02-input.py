my_name = input("Please enter your name: ")

print(my_name)

my_favorite_num = input("Please enter your favorite number: ")

print(my_favorite_num)
print(type(my_favorite_num))

print(my_name.upper())
