print('Hello Python')
print("Hello Python")

print(100)
print(-20)

print(True)
print(False)

print([])
print([1, 2, 3])

print({})
print({'name': 'Bogdan'})
print({
    'name': 'Bogdan',
    'is_instructor': True
})
