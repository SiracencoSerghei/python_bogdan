from math import pi

print(pi)
