import utils

print(utils)
print(type(utils))
print(dir(utils))

print(utils.my_name)
print(utils.hello(utils.my_name))
