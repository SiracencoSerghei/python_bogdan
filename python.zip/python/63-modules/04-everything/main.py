from utils import *

my_name = 'Alice'

print(dir())
print(hello('Bogdan'))
print(my_name)
