print("MODULE NAME: OTHER")

print('OTHER', __name__)
print('OTHER', __name__ == '__main__')

if __name__ == '__main__':
    print('OTHER:', 'ONLY IF RUN DIRECTLY')
