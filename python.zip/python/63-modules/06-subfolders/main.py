from src.other import sum_fn
from src import utils as my_utils

print(sum_fn(10, 2))

print(my_utils.hello('Bogdan'))
print(my_utils.my_name)


def main():
    print("Running main block of code")
