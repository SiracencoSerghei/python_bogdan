import utils

print(utils.hello('Bogdan'))


def sum_fn(a, b):
    return a + b
