def hello(name):
    return f"Hello {name}"


print('UTILS')

my_name = 'Bogdan'
