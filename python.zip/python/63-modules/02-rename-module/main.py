import utils as u

print(u)
print(type(u))
print(dir(u))

print(u.my_name)
print(u.hello(u.my_name))
