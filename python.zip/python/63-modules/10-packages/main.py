from my_package.module_one import my_num
from my_package.module_two import my_name

print(my_num)
print(my_name)

# from my_package import module_one, module_two
#
# print(module_one.my_num)
# print(module_two.my_name)
