my_num = 10
