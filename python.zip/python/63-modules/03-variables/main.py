from utils import hello, my_name as name

print(hello('Bogdan'))
print(name)

print(dir())
