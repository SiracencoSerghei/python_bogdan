def hello(name):
    return f"Hello {name}"


my_name = 'Bogdan'
