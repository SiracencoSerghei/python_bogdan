from main import initialize

initialize()
