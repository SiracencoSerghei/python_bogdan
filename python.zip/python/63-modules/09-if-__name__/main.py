def initialize():
    # Code to initialize application and perform setup
    print("Initializing...")


def main():
    # Code for main app functionality
    print("Running main functionality...")


if __name__ == '__main__':
    initialize()
    main()
