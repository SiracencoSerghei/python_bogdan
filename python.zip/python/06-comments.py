# Single line comment

# Multi
# line
# comment

print(777)  # Printing 777 to the terminal
print('Bogdan')  # Printing my name to the terminal
