print(isinstance(777, int))
print(isinstance(777, object))
print(isinstance('Bogdan', str))
print(isinstance('Bogdan', object))
print(type(object))  # <class 'type'>
