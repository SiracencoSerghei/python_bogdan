long_str = "This is a very long string"

long_str = 'It\'s a great day today'

long_str = "This is a " \
           "very long " \
           "string"

long_str = """This is a very, very,
 very, very, very, very, very,
 very, very, very, very, very, very,
 very, very, very, very, very, very long string"""

print(long_str)
print(type(long_str))
print(type(long_str) == str)
print(id(long_str))
