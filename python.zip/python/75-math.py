import math

print(math.e)
print(math.pi)

print(math.sqrt(225))
print(math.sqrt(230.5))

print(math.factorial(10))  # 1 * 2 * 3 * ... * 10

print(math.log10(100))
print(math.log10(1000))
print(math.log2(8))

print(math.floor(10.7))
print(round(10.7))
