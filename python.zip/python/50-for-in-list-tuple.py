# 1. Iteration of the list using "for in" loop
countries = ['USA', 'Canada', 'UK', 'Australia']

for country in countries:
    print(f"Welcome to the {country}")


# 2. Iteration of the tuple using "for in" loop
countries = ['USA', 'Canada', 'UK', 'Australia']

for country in countries:
    print(f"Welcome to the {country}")
