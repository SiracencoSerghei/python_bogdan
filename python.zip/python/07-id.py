my_name = 'Bogdan'
print(id(my_name))

my_num = 777

other_num = my_num
print(id(my_num) == id(other_num))
